/*
 *  Copyright (c) 2001 Federico 'Simon' Simoncelli <f.simon@email.it>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

#include "config.h"

#include <stdio.h>

#define __USE_BSD
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>

#include <getopt.h>

#include "util.h"

char *make_command(int argc, char *argv[])
{
  char *str = NULL;
  int cx, len, idx;

  if (argc < 1)
    return NULL;

  for (cx = 0, idx = 0; cx < argc; ++cx) {
    len = strlen(argv[cx]) + 1;

    str = realloc(str, idx + len);

    memmove(&str[idx], argv[cx], len - 1);
    idx = idx + len;

    str[idx - 1] = ' ';
  }

  str[idx - 1] = 0x00;

  return str;
}

void usage(char *name)
{
  printf("\n usage: %s [options] command ...\n\n", name);
  printf(" options:\n");
  printf("   -h, --help     display this help.\n");
#ifdef __VERSION_
  printf("       --version  display the version.\n");
#endif
  printf("   -l, --log      sets the log file name.\n");
  printf("   -L, --list     sets the list file name.\n\n");
}

int main(int argc, char **argv)
{
  int c;
  char *args[4], *list = NULL, *log = NULL;

  static struct option long_options[] = {
    {"help", 0, 0, 'h'},
#ifdef __VERSION_
    {"version", 0, 0, 'v'},
#endif
    {"log", 1, 0, 'l'},
    {"list", 1, 0, 'L'}
  };

  while (!NULL) {
    int option_index = 0;

    c = getopt_long(argc, argv, "hl:L:", long_options, &option_index);
    if (c == -1)
      break;

    switch (c) {
    case 'h':
      usage(argv[0]);
      exit(0);

#ifdef __VERSION_
    case 'v':
      printf("%s version: %s\n\n", argv[0], __VERSION_);
      exit(0);
#endif

    case 'l':
      log = optarg;
      break;

    case 'L':
      list = optarg;
      break;

    default:
    }
  }

  if (optind == argc) {
    usage(argv[0]);
    exit(0);
  }

  args[0] = "sh";
  args[1] = "-c";
  args[2] = make_command(argc - optind, &argv[optind]);
  args[3] = 0x00;

  setenv("LD_PRELOAD", "libitrace.so", 1);

  if (log != NULL) {
    char *real_log = get_absolute_path(log);

    setenv(TRACELOG_VAR, real_log, 1);
    fprintf(stderr, "itrace> log file . . . : %s\n", real_log);

    free(real_log);
  }

  if (list != NULL) {
    char *real_list = get_absolute_path(list);

    if (list)
      setenv(TRACELIST_VAR, real_list, 1);
    fprintf(stderr, "itrace> list file  . . : %s\n", real_list);

    free(real_list);
  }

  if ((log == NULL) && (list == NULL))
    fprintf(stderr,
	    "itrace> warning  . . . : you have not selected log or list files.\n");

  fprintf(stderr, "itrace> execute  . . . : %s\n", args[2]);
  execv("/bin/sh", args);

  free(args[2]);

  unsetenv("LD_PRELOAD");
  unsetenv(TRACELOG_VAR);
  unsetenv(TRACELIST_VAR);

  exit(0);
}
