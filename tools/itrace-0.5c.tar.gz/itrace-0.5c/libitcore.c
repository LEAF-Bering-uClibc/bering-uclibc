/*
 *  Copyright (c) 2001 Federico 'Simon' Simoncelli <f.simon@email.it>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <fcntl.h>
#include <dlfcn.h>

#include <stdarg.h>

#include <sys/types.h>
#include <sys/stat.h>

#include "libitrace.h"
#include "util.h"

static FILE *logf = NULL, *listf = NULL;
void *lib = NULL;

void itrace_log_open(void)
{
  if (logf == NULL)
    logf = fopen(getenv(TRACELOG_VAR), "a");

  if (logf == NULL) {
    perror("Can't open file trace log");
    exit(EXIT_FAILURE);
  }
}

void itrace_list_open(void)
{
  if (listf == NULL)
    listf = fopen(getenv(TRACELIST_VAR), "a");

  if (listf == NULL) {
    perror("Can't open file trace log");
    exit(EXIT_FAILURE);
  }
}

void itrace_log(const char *fmt, ...)
{
  va_list ap;
  va_start(ap, fmt);

  if (getenv(TRACELOG_VAR) == NULL)
    return;

  if (logf == NULL)
    itrace_log_open();

  vfprintf(logf, fmt, ap);

  va_end(ap);
}

void itrace_list(const char *path)
{
  char *real;

  if (getenv(TRACELIST_VAR) == NULL) return;

  real = get_absolute_path(path);

  if (listf == NULL) itrace_list_open();

  fprintf(listf, "%s\n", real);

  free(real);
}

void check_libc(void)
{
  void *lib = NULL;

  if (lib == NULL) {
    lib = dlopen("libc.so.6", RTLD_LAZY);
    if (lib == NULL)
      lib = dlopen("libc.so.5", RTLD_LAZY);
    if (lib == NULL) {
      fprintf(stderr, "itrace: Error, I cant find dynamic libc libarary!");
    }

    libc_truncate = dlsym(lib, "truncate");
    libc_creat = dlsym(lib, "creat");
    libc_open = dlsym(lib, "open");
    libc_mkdir = dlsym(lib, "mkdir");
    libc_mknod = dlsym(lib, "mknod");
    libc_rename = dlsym(lib, "rename");
    libc_link = dlsym(lib, "symlink");
    libc_symlink = dlsym(lib, "symlink");

    libc_chmod = dlsym(lib, "chmod");
    libc_chown = dlsym(lib, "chown");
    libc_unlink = dlsym(lib, "unlink");

#ifdef HAVE_OPEN64
    libc_creat64 = dlsym(lib, "creat64");
    libc_open64 = dlsym(lib, "open64");
    libc_truncate64 = dlsym(lib, "truncate64");
#endif
  }

}
