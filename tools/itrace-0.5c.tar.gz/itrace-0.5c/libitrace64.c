/*
 *  Copyright (c) 2001 Federico 'Simon' Simoncelli <f.simon@email.it>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

#include "config.h"

#ifdef HAVE_OPEN64

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <fcntl.h>
#include <dlfcn.h>

#include <stdarg.h>

#include <sys/types.h>
#include <sys/stat.h>

#include "libitrace.h"


int open64(const char *pathname, int flags, ...)
{
  va_list ap;
  mode_t mode;
  int ret;

  va_start(ap, flags);
  mode = va_arg(ap, mode_t);
  va_end(ap);

  check_libc();
  ret = libc_open64(pathname, flags, mode);

  if (check_path(pathname)) return ret;

  if ((flags & O_WRONLY) || (flags & O_RDWR) || (flags & O_CREAT)) {
    itrace_log("open64(\"%s\", 0x%08x , %04o) = %i\n", pathname, flags,
	       mode, ret);
    if (ret > 0)
      itrace_list(pathname);
  }

  return ret;
}

int creat64(const char *pathname, mode_t mode)
{
  int ret;

  check_libc();
  ret = libc_open64(pathname, O_WRONLY | O_CREAT | O_TRUNC, mode);

  if (check_path(pathname)) return ret;

  itrace_log("creat64(\"%s\", %04o) = %i\n", pathname, mode, ret);
  if (ret != -1)
    itrace_list(pathname);

  return ret;
}

int truncate64(const char *pathname, off64_t length)
{
  int ret;

  check_libc();
  ret = libc_truncate64(pathname, length);

  itrace_log("truncate64(\"%s\", %i) = %i\n", pathname, length, ret);
  if (ret != -1)
    itrace_list(pathname);

  return ret;

}

#endif
