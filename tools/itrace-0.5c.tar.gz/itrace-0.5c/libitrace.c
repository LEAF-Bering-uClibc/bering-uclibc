/*
 *  Copyright (c) 2001 Federico 'Simon' Simoncelli <f.simon@email.it>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <fcntl.h>
#include <dlfcn.h>

#include <stdarg.h>

#include <sys/types.h>
#include <sys/stat.h>

#include "util.h"
#include "libitrace.h"


int truncate(const char *pathname, off_t length)
{
  int ret;

  check_libc();
  ret = libc_truncate(pathname, length);

  itrace_log("truncate(\"%s\", %i) = %i\n", pathname, length, ret);
  if (ret != -1)
    itrace_list(pathname);

  return ret;
}

int creat(const char *pathname, mode_t mode)
{
  int ret;

  check_libc();
  ret = libc_open(pathname, O_WRONLY | O_CREAT | O_TRUNC, mode);

  if (check_path(pathname)) return ret;

  itrace_log("creat(\"%s\", %04o) = %i\n", pathname, mode, ret);
  if (ret != -1)
    itrace_list(pathname);

  return ret;
}

int open(const char *pathname, int flags, ...)
{
  int ret;
  mode_t mode;

  va_list ap;
  va_start(ap, flags);

  check_libc();
  mode = va_arg(ap, mode_t);
  ret = libc_open(pathname, flags, mode);
  va_end(ap);

  if (check_path(pathname)) return ret;

  if ((flags & O_WRONLY) || (flags & O_RDWR) || (flags & O_CREAT)) {
    itrace_log("open(\"%s\", 0x%08x, %04o) = %i\n", pathname, flags, mode,
	       ret);
    if (ret > 0)
      itrace_list(pathname);
  }

  return ret;
}

int mkdir(const char *pathname, mode_t mode)
{
  int ret;

  check_libc();
  ret = libc_mkdir(pathname, mode);

  if (check_path(pathname)) return ret;

  itrace_log("mkdir(\"%s\", %04o) = %i\n", pathname, mode, ret);
  if (!ret)
    itrace_list(pathname);

  return ret;
}

int mknod(const char *pathname, mode_t mode, dev_t dev)
{
  int ret;

  check_libc();
  ret = libc_mknod(pathname, mode, dev);

  itrace_log("mknod(\"%s\", %04o, %i) = %i\n", pathname, mode, dev, ret);
  if (!ret)
    itrace_list(pathname);

  return ret;
}

int rename(const char *oldpath, const char *newpath)
{
  int ret;

  check_libc();
  ret = libc_rename(oldpath, newpath);

  itrace_log("rename(\"%s\", \"%s\") = %i\n", oldpath, newpath, ret);
  if (!ret)
    itrace_list(newpath);

  return ret;
}

int link(const char *oldpath, const char *newpath)
{
  int ret;

  check_libc();
  ret = libc_link(oldpath, newpath);

  itrace_log("link(\"%s\", \"%s\") = %i\n", oldpath, newpath, ret);
  if (!ret)
    itrace_list(newpath);

  return ret;
}

int symlink(const char *oldpath, const char *newpath)
{
  int ret;

  check_libc();
  ret = libc_symlink(oldpath, newpath);

  itrace_log("symlink(\"%s\", \"%s\") = %i\n", oldpath, newpath, ret);
  if (!ret)
    itrace_list(newpath);

  return ret;
}

int chmod(const char *path, mode_t mode)
{
  int ret;

  check_libc();
  ret = libc_chmod(path, mode);

  itrace_log("chmod(\"%s\", %o) = %i\n", path, mode, ret);

  return ret;
}

int chown(const char *path, uid_t owner, gid_t group)
{
  int ret;

  check_libc();
  ret = libc_chown(path, owner, group);

  itrace_log("chown(\"%s\", %i, %i) = %i\n", path, owner, group);

  return ret;
}

int unlink(const char *pathname)
{
  int ret;

  check_libc();
  ret = libc_unlink(pathname);

  itrace_log("unlink(\"%s\") = %i\n", pathname);

  return ret;
}
