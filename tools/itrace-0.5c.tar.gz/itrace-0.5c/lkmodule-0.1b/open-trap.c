/*
 *  Copyright (c) 2001 Federico 'Simon' Simoncelli <f.simon@email.it>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  compile:
 *     gcc -O2 -Wall -I/usr/src/linux/include -fomit-frame-pointer \
 *         -o open-trap.o -c open-trap.c
 *  use: insmod ./open-trap.o
 */

#define __KERNEL__
#define MODULE

#include <linux/module.h>

#include <asm/uaccess.h>
#include <linux/fcntl.h>

#include <sys/syscall.h>
extern void *sys_call_table[];

#define _LOG_FILE__ "/tmp/listfile.log"

MODULE_LICENSE("GPL");

int (*old_open) (const char *, int, unsigned int);
int (*old_symlink) (const char *, const char *);
int (*old_mkdir) (const char *, unsigned int);
int new_open(const char *, int, unsigned int);
int new_symlink(const char *, const char *);
int new_mkdir(const char *, unsigned int);

int (*write)(unsigned int, const char*, unsigned int);
int (*close)(int);

inline int trap_logpath(const char *str)
{
  int kflog_fd, str_sz;
  mm_segment_t old_fs;

  str_sz = strlen(str);

  current->cap_effective |= (1 << (CAP_DAC_OVERRIDE));
  old_fs=current->addr_limit;
  current->addr_limit=(KERNEL_DS);

  if( strncmp(str, "/dev", strlen("/dev")) &&
      strncmp(str, "/tmp", strlen("/tmp")) ) {

    kflog_fd = old_open(_LOG_FILE__, O_CREAT|O_RDWR|O_APPEND, 0644);
    str_sz = write(kflog_fd, str, str_sz);
    write(kflog_fd, "\n", strlen("\n"));
    close(kflog_fd);
  }

  current->addr_limit=old_fs;
  current->cap_effective &= ~(1 << (CAP_DAC_OVERRIDE));

  return str_sz;
}

int new_mkdir(const char *pathname, unsigned int mode)
{
  int ret = old_mkdir(pathname, mode);
  trap_logpath(pathname);
  return ret; 
}

int new_symlink(const char *oldpath, const char *newpath)
{
  int ret = old_symlink(oldpath, newpath);
  trap_logpath(newpath);
  return ret; 
}

int new_open(const char *filename, int flags, unsigned int mode)
{
  int ret = old_open(filename, flags, mode);
  trap_logpath(filename);
  return ret; 
}

int init_module(void)
{
  EXPORT_NO_SYMBOLS;

  printk("Module open-trap.o Loaded. (beta UNSTABLE release)\n");
  printk("Send BUGS to: Federico 'simon' Simoncelli <f.simon@email.it>\n");

  old_open = sys_call_table[__NR_open];
  sys_call_table[__NR_open] = (void *) new_open;
  old_symlink = sys_call_table[__NR_symlink];
  sys_call_table[__NR_symlink] = (void *) new_symlink;
  old_mkdir = sys_call_table[__NR_mkdir];
  sys_call_table[__NR_mkdir] = (void *) new_mkdir;

  close = sys_call_table[__NR_close];
  write = sys_call_table[__NR_write];

  return 0;
}

int cleanup_module(void)
{
  sys_call_table[__NR_open] = (void *) old_open;
  sys_call_table[__NR_symlink] = (void *) old_symlink;
  sys_call_table[__NR_mkdir] = (void *) old_mkdir; 

  return 0;
}

