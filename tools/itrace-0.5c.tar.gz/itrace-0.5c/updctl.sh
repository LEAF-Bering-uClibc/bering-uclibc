#!/bin/sh
pwd | awk -F/ '{ printf "%s ", $(NF) }' && date -R

