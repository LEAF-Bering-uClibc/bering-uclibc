/*
 *  Copyright (c) 2001 Federico 'Simon' Simoncelli <f.simon@email.it>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

#ifndef __LIBITRACE_H_
#define __LIBITRACE_H_


int (*libc_truncate) (const char *, off_t);
int (*libc_creat) (const char *, mode_t);
int (*libc_open) (const char *, int, ...);
int (*libc_link) (const char *, const char *);
int (*libc_mkdir) (const char *, mode_t);
int (*libc_mknod) (const char *, mode_t, dev_t);
int (*libc_rename) (const char *, const char *);
int (*libc_symlink) (const char *, const char *);

int (*libc_chmod) (const char *, mode_t);
int (*libc_chown) (const char *, uid_t, gid_t);
int (*libc_unlink) (const char *pathname);

#ifdef HAVE_OPEN64
typedef __off64_t off64_t;

int (*libc_open64) (const char *, int, ...);
int (*libc_creat64) (const char *, mode_t);
int (*libc_truncate64) (const char *, __off64_t);
#endif


void itrace_log_open(void);
void itrace_list_open(void);

void itrace_log(const char *, ...);
void itrace_list(const char *);


void check_libc(void);

#endif
